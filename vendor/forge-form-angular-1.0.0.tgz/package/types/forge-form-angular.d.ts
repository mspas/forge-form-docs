import * as _angular_forms from '@angular/forms';
import { ValidationErrors, AbstractControl, FormGroup, FormControl } from '@angular/forms';
import * as i0 from '@angular/core';
import { Type, Signal, InjectionToken } from '@angular/core';

type ErrorMessageContent = string | ((error: ValidationErrors) => string) | ErrorComponentDef;
interface ErrorComponentDef {
    component: Type<unknown>;
    inputs?: (data: unknown) => Record<string, unknown>;
}
interface ErrorMessage {
    type: ValidatorType;
    message: ErrorMessageContent;
}

type ValidatorSchema = RequiredValidatorSchema | MinLengthValidatorSchema | MaxLengthValidatorSchema | MinValidatorSchema | MaxValidatorSchema | CustomValidatorSchema;
declare const VALIDATOR_TYPES: {
    readonly required: "required";
    readonly minlength: "minlength";
    readonly maxlength: "maxlength";
    readonly min: "min";
    readonly max: "max";
    readonly custom: "custom";
};
type ValidatorType = (typeof VALIDATOR_TYPES)[keyof typeof VALIDATOR_TYPES];
interface BaseValidatorSchema {
    type: ValidatorType;
    errorMessage?: ErrorMessageContent;
}
interface RequiredValidatorSchema extends BaseValidatorSchema {
    type: typeof VALIDATOR_TYPES.required;
}
interface MinLengthValidatorSchema extends BaseValidatorSchema {
    type: typeof VALIDATOR_TYPES.minlength;
    value: number;
}
interface MaxLengthValidatorSchema extends BaseValidatorSchema {
    type: typeof VALIDATOR_TYPES.maxlength;
    value: number;
}
interface MinValidatorSchema extends BaseValidatorSchema {
    type: typeof VALIDATOR_TYPES.min;
    value: number;
}
interface MaxValidatorSchema extends BaseValidatorSchema {
    type: typeof VALIDATOR_TYPES.max;
    value: number;
}
interface CustomValidatorSchema extends BaseValidatorSchema {
    type: typeof VALIDATOR_TYPES.custom;
    key: string;
    fn: ValidatorFunction;
}
type ValidatorFunction = (control: AbstractControl) => ValidationErrors | null;

declare const UPDATE_ON: {
    readonly change: "change";
    readonly blur: "blur";
    readonly submit: "submit";
};
type UpdateOn = (typeof UPDATE_ON)[keyof typeof UPDATE_ON];

declare const ORIENTATION_OPTIONS: {
    readonly row: "row";
    readonly column: "column";
};
type OrientationOption = (typeof ORIENTATION_OPTIONS)[keyof typeof ORIENTATION_OPTIONS];
declare const THEMES: {
    readonly none: "none";
    readonly default: "default";
};
type ThemeOption = (typeof THEMES)[keyof typeof THEMES];
interface BaseFormOptions {
    orientation?: OrientationOption;
    labelOrientation?: OrientationOption;
}
interface FormOptions extends BaseFormOptions {
    theme?: ThemeOption;
}
type ElementFormOptions = BaseFormOptions;
interface FormFieldOptions extends BaseFormOptions {
    width?: number | string;
}

declare const HINT_TYPES: {
    readonly text: "text";
    readonly custom: "custom";
};
type HintType = (typeof HINT_TYPES)[keyof typeof HINT_TYPES];
type HintMessage = string | HintComponentDef;
interface HintComponentDef {
    component: Type<unknown>;
    inputs?: Record<string, unknown>;
}
interface HintContext {
    control: AbstractControl;
    value: Signal<unknown>;
    errors: Signal<ValidationErrors | null>;
}

interface VisibilitySchema {
    fn: VisibilityFunction;
    behavior: VisibilityBehavior;
    clearOnHide?: boolean;
}
type VisibilityFunction = (control: VisibilityContext) => boolean;
declare const VISIBILITY_BEHAVIORS: {
    readonly hide: "hide";
    readonly disable: "disable";
};
type VisibilityBehavior = (typeof VISIBILITY_BEHAVIORS)[keyof typeof VISIBILITY_BEHAVIORS];
interface VisibilityContext {
    value: unknown;
    form: FormGroup;
    control: AbstractControl;
}

type ControlSchema = TextControlSchema | NumberControlSchema | CheckboxControlSchema | SelectControlSchema;
interface BaseElementSchema {
    type: string;
    label?: string;
}
interface BaseControlSchema extends BaseElementSchema {
    controlName: string;
    options?: FormFieldOptions;
    initialValue?: unknown;
    validators?: ValidatorSchema[];
    visibility?: VisibilitySchema;
    updateOn?: UpdateOn;
    hint?: HintMessage;
}
interface TextControlSchema extends BaseControlSchema {
    type: 'text';
    placeholder?: string;
}
interface NumberControlSchema extends BaseControlSchema {
    type: 'number';
    placeholder?: string;
    min?: number;
    max?: number;
}
interface CheckboxControlSchema extends BaseControlSchema {
    type: 'checkbox';
}
interface SelectControlSchema extends BaseControlSchema {
    type: 'select';
    items: SelectOption[];
    placeholder?: string;
}
interface SelectOption {
    label: string;
    value: string;
}
interface FieldRenderer<TSchema = unknown> {
    control: FormControl;
    controlSchema: TSchema;
}

interface GroupFieldSchema extends BaseElementSchema {
    type: 'group';
    controls: (GroupFieldSchema | ControlSchema)[];
    options?: ElementFormOptions;
}
interface FormSchema {
    controls: (GroupFieldSchema | ControlSchema)[];
    id?: string;
    updateOn?: UpdateOn;
    options?: FormOptions;
}

declare class FormRendererComponent<TModel> {
    private readonly formService;
    readonly schema: i0.InputSignal<FormSchema>;
    readonly formSubmit: i0.OutputEmitterRef<TModel>;
    readonly THEMES: {
        readonly none: "none";
        readonly default: "default";
    };
    readonly formSignal: i0.WritableSignal<_angular_forms.FormGroup<any> | null>;
    constructor();
    getControl(name: string): FormControl;
    onSubmit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormRendererComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormRendererComponent<any>, "forge-form-angular", never, { "schema": { "alias": "schema"; "required": true; "isSignal": true; }; }, { "formSubmit": "formSubmit"; }, never, never, true, never>;
}

declare abstract class FormFieldContextComponent<T = unknown> {
    control: i0.InputSignal<AbstractControl<T, T, any>>;
    controlValue: i0.InputSignal<T>;
    controlErrors: i0.InputSignal<ValidationErrors | null>;
    controlSchema: i0.InputSignal<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormFieldContextComponent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FormFieldContextComponent<any>, never, never, { "control": { "alias": "control"; "required": true; "isSignal": true; }; "controlValue": { "alias": "controlValue"; "required": true; "isSignal": true; }; "controlErrors": { "alias": "controlErrors"; "required": false; "isSignal": true; }; "controlSchema": { "alias": "controlSchema"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare const FORM_OPTIONS: InjectionToken<FormOptions>;

interface RendererDef {
    type: string;
    component: Type<FieldRenderer>;
}
declare const RENDERERS: InjectionToken<RendererDef[]>;
declare class RendererRegistry {
    private map;
    constructor(renderers?: RendererDef[][]);
    get(type: string): Type<FieldRenderer>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RendererRegistry, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RendererRegistry>;
}

interface ValidatorCredentials {
    value?: number | string;
    key?: string;
    fn?: ValidatorFunction;
    errorMessage?: ErrorMessageContent;
}
declare const required: (credentials?: ValidatorCredentials) => ValidatorSchema;
declare const minLength: ({ value, errorMessage, }: ValidatorCredentials) => ValidatorSchema;
declare const maxLength: ({ value, errorMessage, }: ValidatorCredentials) => ValidatorSchema;
declare const min: ({ value, errorMessage, }: ValidatorCredentials) => ValidatorSchema;
declare const max: ({ value, errorMessage, }: ValidatorCredentials) => ValidatorSchema;
declare const customValidator: ({ key, fn, errorMessage, }: ValidatorCredentials) => ValidatorSchema;

declare const ERROR_MESSAGES: InjectionToken<ErrorMessage[]>;
declare const DEFAULT_ERROR_FALLBACK: InjectionToken<string>;
declare const DEFAULT_ERROR_MESSAGES: ErrorMessage[];

export { DEFAULT_ERROR_FALLBACK, DEFAULT_ERROR_MESSAGES, ERROR_MESSAGES, FORM_OPTIONS, FormFieldContextComponent, FormRendererComponent, HINT_TYPES, ORIENTATION_OPTIONS, RENDERERS, RendererRegistry, THEMES, UPDATE_ON, VALIDATOR_TYPES, VISIBILITY_BEHAVIORS, customValidator, max, maxLength, min, minLength, required };
export type { BaseControlSchema, BaseElementSchema, BaseValidatorSchema, CheckboxControlSchema, ControlSchema, CustomValidatorSchema, ElementFormOptions, ErrorComponentDef, ErrorMessage, ErrorMessageContent, FieldRenderer, FormFieldOptions, FormOptions, FormSchema, GroupFieldSchema, HintComponentDef, HintContext, HintMessage, HintType, MaxLengthValidatorSchema, MaxValidatorSchema, MinLengthValidatorSchema, MinValidatorSchema, NumberControlSchema, OrientationOption, RendererDef, RequiredValidatorSchema, SelectControlSchema, SelectOption, TextControlSchema, ThemeOption, UpdateOn, ValidatorCredentials, ValidatorFunction, ValidatorSchema, ValidatorType, VisibilityBehavior, VisibilityContext, VisibilityFunction, VisibilitySchema };
